# Troubleshooting
See [Grafana troubleshooting](http://docs.grafana.org/installation/troubleshooting/) for general
connection issues. If you have a problem with Zabbix datasource, you should open
a [support issue](https://github.com/alexanderzobnin/grafana-zabbix/issues). Before you do that
please search the existing closed or open issues.
