## Apica Panels

A Grafana App plugin that contains custom Grafana plugins for Apica Synthetic Monitoring.

### Contents

1. Apica Synthetic Monitoring Grafana Data Source plugin
2. Apica Status Panel plugin
3. Apica Worldmap Panel plugin

### How To Install

**Note:** Installation via [grafana-cli](http://docs.grafana.org/administration/cli/) is not supported.

#### Manual Installation

To install Apica Panels App plugin manually:

1. Download the Apica Panels App plugin package `.zip` file.

2. Find the plugin directory on the Grafana server:
 * Linux: `/var/lib/grafana/plugins`
 * Windows: `{grafana directory}/data/plugins`

3. Unzip the contents of package `.zip` file into plugins directory

The folder should have the same name as the plugin.

4. Restart the Grafana Server.


#### Directory Options

The path to the Grafana plugins directory is defined in the [grafana settings](http://docs.grafana.org/installation/configuration/) `.ini` file.

The setting for directories is in the `[paths]` section.


#### Additional Documentation

General Grafana plugin installation documentation is available here: [http://docs.grafana.org/plugins/installation/](http://docs.grafana.org/plugins/installation/#installing-plugins-manually).


### Changelog

#### v1.0.0

Include all current Apica plugins for Grafana:

* Apica Synthetic Monitoring datasource - v1.1.1
* Apica Status panel - v1.0.2
* Apica Worldmap panel - v0.1.1

You do not need to install them separately.

#### v1.1.0

* Apica Synthetic Monitoring datasource - v1.1.3
* Apica Status panel - v1.0.2
* Apica Worldmap panel - v0.1.1
* Apica Graph panel - v0.0.1

#### v1.1.1

* Apica Synthetic Monitoring datasource - v1.1.3
* Apica Status panel - v1.0.3
* Apica Worldmap panel - v0.1.1
* Apica Graph panel - v0.0.1

#### v1.1.2

* Apica Synthetic Monitoring datasource - v1.1.4
* Apica Status panel - v1.0.3
* Apica Worldmap panel - v0.1.1
* Apica Graph panel - v0.0.1