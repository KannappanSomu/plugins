'use strict';

System.register([], function (_export, _context) {
  "use strict";

  var ApicaAppConfigCtrl, AboutCtrl;

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  return {
    setters: [],
    execute: function () {
      _export('ConfigCtrl', ApicaAppConfigCtrl = function ApicaAppConfigCtrl() {
        _classCallCheck(this, ApicaAppConfigCtrl);
      });

      // empty template, no settings for now. Can be separated to an html file and referenced via templateUrl
      ApicaAppConfigCtrl.template = '\n  <h2>Apica Panels</h2>\n';

      _export('AboutCtrl', AboutCtrl = function AboutCtrl() {
        _classCallCheck(this, AboutCtrl);
      });

      // note that plugin id (apica-status-panel) is hardcoded here as templateUrl is static
      // it isn't clear how to avoid hardcode (like it was done in the constructor using $scope.ctrl.pluginId)
      AboutCtrl.templateUrl = '../../plugins/apica-panels-app/components/about.html';

      _export('ConfigCtrl', ApicaAppConfigCtrl);

      _export('AboutCtrl', AboutCtrl);
    }
  };
});
//# sourceMappingURL=module.js.map
